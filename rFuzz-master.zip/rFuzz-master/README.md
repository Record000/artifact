# RPKI Fuzzer

A specialized fuzzer for Resource Public Key Infrastructure (RPKI) testing.

## Root Directory Files

- **main.py** - Main entry point. Builds RPKI certificate hierarchies, generates mutated certificates (CA, EE), manifests (MFT), route origin authorizations (ROA), CRLs, and RRDP. Includes RFC 6487 compliance validation.

- **test_noDep.py** - Fuzzing test runner. Executes 50 experimental runs, analyzes parsing stages across multiple RPKI validators (Routinator, Fort, Octorpki, RPKI Client), and outputs hit statistics.

- **test_coverage.py** - Performance benchmarking tool. Generates 1000 test repositories, monitors CPU and memory usage during generation, and produces resource usage distribution plots.

- **test_eff.py** - Empty file (reserved).

## Test Directory Files

### Benchmark Tools

- **no_dep.py** - Dependency mutation benchmarking tool. Tests mutation configuration generation time and overhead across different tree scales (small, medium, large, deep).

- **test_mutate_times_0.py** - Initial mutation overhead testing tool. Measures performance for generating mutated CA/EE JSON configurations at various tree depths and branching factors.

- **test_mutate_times_1.py** - Enhanced mutation timing tool. Provides fine-grained timing measurements for individual field mutation operations with per-field statistics.

- **test_mutate_times_2.py** - Dependency repair timing tool. Simulates and measures the time cost of fixing dependency relationships between mutated fields.

- **test_mutate_times_3.py** - Full lifecycle cost model tool. Breaks down total mutation cost into four components: T_mut (mutation), T_rep (dependency repair), T_resin (signing simulation), and T_io (disk I/O).

### Rebuild Tools

- **rebuild_cert.py** - CA certificate rebuild tool. Parses CA certificate JSON configurations and reconstructs certificates, testing rebuild correctness.

- **rebuild_crl.py** - CRL rebuild tool. Parses Certificate Revocation List JSON configurations and reconstructs CRLs.

- **rebuild_ee.py** - EE certificate rebuild tool. Parses and reconstructs End-Entity certificates used in MFTs and ROAs.

- **rebuild_mft.py** - Empty file (reserved).

### Parsing Tools

- **parse_cert.py** - Certificate parsing utility. Reads and extracts all fields from JSON-formatted CA certificates for debugging and validation.

- **xml.py** - RRDP delta generation tool. Generates incremental RRDP updates (delta.xml and notification.xml) based on existing repository snapshots.

### Data Files

- **octorpki_output.json** - Output from octorpki validator.

- **routinator_output.csv** - Output from routinator validator.

- **rpki-client_output/** - Directory containing outputs from rpki-client validator.

- **field_time_stats.json** - Field mutation timing statistics.

- **input_scale_results.json** - Input scaling test results.

- **test_bench_repo/** - Benchmark test repository directory containing sample RPKI objects.
